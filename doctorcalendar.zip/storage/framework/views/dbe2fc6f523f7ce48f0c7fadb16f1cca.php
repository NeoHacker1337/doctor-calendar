<link rel="shortcut icon" href="<?php echo e(asset('assets/images/doctor_logo_dark.ico')); ?>">

 
<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

<link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<?php /**PATH D:\wamp64\www\doctorcalendar\resources\views/layouts/css.blade.php ENDPATH**/ ?>