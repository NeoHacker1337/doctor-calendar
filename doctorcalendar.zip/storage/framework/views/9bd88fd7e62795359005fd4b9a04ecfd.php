
<?php $__env->startSection('content'); ?>



    <!-- Start content -->
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <?php if(Auth::guard('admin')->user()->role === 'admin'): ?>
                            <h4 class="page-title">Doctor List</h4>
                        <?php else: ?>
                            <h4 class="page-title"><a href="<?php echo e(Route('doctors.create')); ?>">Add Doctor</a></h4>
                        <?php endif; ?>
                    </div>

                </div>
                <!-- end row -->
            </div>
            <!-- end page-title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <table class="table table-striped table-bordered dt-responsive nowrap" id="mrTable"
                                style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th>S.No.</th>
                                        <th>Hospital Name</th>
                                        <th>Registration No.</th>
                                        <th>Education</th>
                                        <th>Specialization</th>
                                        <th>Address</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>DOB</th>
                                        <th>Marriage Anniversary</th>
                                        <th>Date of Joining</th>
                                        <th>Add By</th>
                                        <th>Action</th>

                                    </tr>
                                </thead>

                                <tbody>
                                    <?php if(count($doctor) > 0): ?>
                                        <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($dr->hospital_name); ?></td>
                                                <td><?php echo e($dr->registration_number); ?> </td>
                                                <td><?php echo e($dr->education); ?></td>
                                                <td><?php echo e($dr->specialization); ?></td>
                                                <td><?php echo e($dr->address); ?></td>
                                                <td><?php echo e($dr->email); ?> </td>
                                                <td><?php echo e($dr->contact_number); ?> </td>
                                                <td><?php echo e($dr->date_of_birth); ?></td>
                                                <td><?php echo e($dr->marriage_anniversary ? $dr->marriage_anniversary : 'Date not Selected'); ?>

                                                </td>
                                                <td><?php echo e($dr->created_at); ?> </td>
                                                <td>
                                                    <?php
                                                        // Fetch the user information based on created_by
                                                        $createdByUser = \App\Models\User::find($dr->created_by);
                                                    ?>

                                                    <?php echo e($createdByUser ? $createdByUser->name : 'User not found'); ?>

                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('doctor-list.show', ['doctor_list' => $dr->id])); ?>"
                                                        class="btn btn-sm btn-info" title="View">
                                                        <i class="fa fa-eye"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>

                                            <td colspan="12">No Data Found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->


        </div>
        <!-- container-fluid -->

    </div>
    <!-- content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\doctorcalendar\resources\views/backend/doctor/index.blade.php ENDPATH**/ ?>