<link rel="shortcut icon" href="{{ asset('assets/images/doctor_logo_dark.ico') }}">

 
<link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
{{-- <link href="{{ asset('assets/css/metismenu.min.css') }}" rel="stylesheet" type="text/css"> --}}
<link href="{{ asset('assets/css/icons.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('assets/css/style.css') }}" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
