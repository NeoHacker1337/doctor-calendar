<footer class="footer">
    © 2024 <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Mahender Singh</span>.
</footer>